/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.era7.bioinfo.bioinfoaws.util;

/**
 *
 * @author ppareja
 */
public class AMITypes {

    public static final String BASIC_AMAZON_LINUX_64_BITS = "ami-6e31041a";

}
