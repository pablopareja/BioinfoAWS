/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.era7.bioinfo.bioinfoaws.util;

/**
 *
 * @author ppareja
 */
public class InstanceTypes {

    public static final String MICRO_INSTANCE = "t1.micro";

}
